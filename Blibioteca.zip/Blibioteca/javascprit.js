const produtos = ['caneta', 'lápis', 'borracha', 'régua', 'caderno', 'lapiseira'];
const preços = [5.25, 2.99, 3.99, 5.50, 15.90, 22.59];
const quantidadesEstoque = [27, 53, 60, 33, 28, 15];


//buscar índice do produto
function buscarProduto(nomeProduto) {
  const indiceProduto = produtos.indexOf(nomeProduto);
  if (indiceProduto === -1) {
    throw new Error(`Produto não encontrado: ${nomeProduto}`);
  }
  return indiceProduto;
}


//comprar produtos
function comprarProduto(nomeProduto, quantidadeComprada) {
  const indiceProduto = buscarIndiceProduto(nomeProduto);


  //quantidade suficiente no estoque
  if (quantidadesEstoque[indiceProduto] < quantidadeComprada) {
    throw new Error(`Quantidade insuficiente: ${nomeProduto}. Em estoque: ${quantidadesEstoque[indiceProduto]}, quantidade desejada: ${quantidadeComprada}`);
  }


  quantidadesEstoque[indiceProduto] -= quantidadeComprada;
  console.log(`Compra realizada: ${nomeProduto} (x${quantidadeComprada}). Quantidade restante: ${quantidadesEstoque[indiceProduto]}`);
}


//vender produtos
function venderProduto(nomeProduto, quantidadeVendida) {
  const indiceProduto = buscarIndiceProduto(nomeProduto);


  //verificar se o produto existe no estoque
  if (quantidadesEstoque[indiceProduto] === 0) {
    throw new Error(`Produto sem estoque: ${nomeProduto}`);
  }


  quantidadesEstoque[indiceProduto] += quantidadeVendida;
  console.log(`Venda realizada: ${nomeProduto} (x${quantidadeVendida}). Quantidade atualizada: ${quantidadesEstoque[indiceProduto]}`);
}


//cadastrar novos produtos
function cadastrarProduto(nomeProduto, precoNovo, quantidadeEstoqueInicial) {
  if (produtos.includes(nomeProduto)) {
    throw new Error(`Produto já cadastrado: ${nomeProduto}`);
  }


  produtos.push(nomeProduto);
  preços.push(precoNovo);
  quantidadesEstoque.push(quantidadeEstoqueInicial);
  console.log(`Produto cadastrado: ${nomeProduto}. Preço: R$${precoNovo}. Quantidade em estoque: ${quantidadeEstoqueInicial}`);
}


comprarProduto('caneta', 5);
venderProduto('borracha', 2);
cadastrarProduto('mouse', 29.90, 10); //adiciona novo produto
